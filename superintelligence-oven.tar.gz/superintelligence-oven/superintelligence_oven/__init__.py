"""
Superintelligence Oven 🔥
Multi-agent GRPO training framework.
"""

from .config import (
    OvenConfig,
    AgentConfig,
    TeacherConfig,
    ModelDescription,
)
from .oven import SuperintelligenceOven
from .wrapper import OvenWrapper, bake
from .agents import AgentSwarm
from .teachers import (
    TeacherManager,
    SmallCausalTeacher,
    BigCausalTeacher,
    SmallCausalDiffusionTeacher,
)
from .verifier import QwenEmbedVerifier
from .calibrator import FrontierCalibrator
from .prompts import PromptSource

__version__ = "0.1.0"

__all__ = [
    # Main entry points
    "bake",
    "SuperintelligenceOven",
    "OvenWrapper",
    # Config
    "OvenConfig",
    "AgentConfig",
    "TeacherConfig",
    "ModelDescription",
    # Components
    "AgentSwarm",
    "TeacherManager",
    "SmallCausalTeacher",
    "BigCausalTeacher",
    "SmallCausalDiffusionTeacher",
    "QwenEmbedVerifier",
    "FrontierCalibrator",
    "PromptSource",
]
