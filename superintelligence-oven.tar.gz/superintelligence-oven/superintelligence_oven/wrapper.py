"""
Model-Agnostic Wrapper — The entry point for any model.

Takes any nn.Module + a ModelDescription, configures the oven, and provides
a simple API to train. The ModelDescription becomes a prompt injected into
every agent call so they know what kind of GRPO they're scoring for.

Usage:
    from superintelligence_oven import bake

    # Text model
    oven = bake(
        model=my_causal_lm,
        name="my-assistant-7b",
        modality="text",
        domain="general assistant",
        description="A 7B causal LM fine-tuned for instruction following. "
                    "Uses Qwen2 tokenizer. Trained on chat data.",
        tokenizer=my_tokenizer,
        prompts=["Explain X", "Write Y", ...],
    )
    asyncio.run(oven.run())

    # Diffusion / motion model
    oven = bake(
        model=my_motion_model,
        name="egirl-motion-v2",
        modality="motion",
        domain="motion generation",
        description="A VALM-based motion generator for virtual character animations. "
                    "Outputs 72-dim joint trajectories conditioned on language intent.",
        output_format="trajectory",
        use_verifier=False,      # verifier is text-only
        teacher="diffusion_motion",
        prompts=["wave hello", "dance excited", ...],
    )
    asyncio.run(oven.run())
"""

import asyncio
import torch.nn as nn
from typing import Any, Dict, List, Optional, Union
import logging

from .config import (
    OvenConfig, ModelDescription, TeacherConfig, AgentConfig,
    DEFAULT_AGENTS, DEFAULT_TEACHERS,
)
from .oven import SuperintelligenceOven
from .prompts import PromptSource
from .verifier import QwenEmbedVerifier

log = logging.getLogger("oven.wrapper")


class OvenWrapper:
    """
    Model-agnostic wrapper around SuperintelligenceOven.

    Provides a simplified API:
        - .run()           — train the model
        - .swap_teacher()  — change KL anchor
        - .swap_agent()    — change frontier model for an agent
        - .status()        — current config summary
    """

    def __init__(
        self,
        model: nn.Module,
        description: ModelDescription,
        config: OvenConfig,
        tokenizer=None,
        verifier=None,
        prompts: Optional[List[str]] = None,
    ):
        self.description = description
        self.config = config
        config.model_description = description

        # Disable verifier for non-text modalities
        if not description.use_verifier:
            config.verifier_weight = 0.0
            verifier = None  # explicitly skip

        # Build prompt source
        prompt_source = PromptSource(prompts) if prompts else None

        # Build oven
        self.oven = SuperintelligenceOven(
            config=config,
            policy_model=model,
            tokenizer=tokenizer,
            verifier=verifier,
            prompt_source=prompt_source,
        )

        log.info(
            "[OVEN WRAPPER] Configured for: %s (%s / %s)",
            description.name, description.modality, description.domain,
        )

    # ---- simple API ----

    async def run(self, prompts: Optional[List[str]] = None):
        """Train the model. Optionally override prompts."""
        ps = PromptSource(prompts) if prompts else None
        return await self.oven.train(prompt_source=ps)

    def run_sync(self, prompts: Optional[List[str]] = None):
        """Synchronous version of run()."""
        return asyncio.run(self.run(prompts))

    # ---- delegation ----

    def swap_teacher(self, name: str):
        self.oven.swap_teacher(name)

    def swap_agent(self, agent_name: str, **kw):
        self.oven.swap_agent(agent_name, **kw)

    def swap_all_agents(self, provider: str, model: str, **kw):
        self.oven.swap_all_agents(provider, model, **kw)

    def attach_to_model(self, model):
        self.oven.attach_to_model(model)

    @property
    def metrics(self):
        return self.oven.metrics_history

    def status(self) -> Dict:
        """Current oven status."""
        return {
            "model": self.description.name,
            "modality": self.description.modality,
            "domain": self.description.domain,
            "teacher": self.oven.teacher_mgr.current_name,
            "teacher_kind": self.oven.teacher_mgr.current_kind,
            "agents": {
                a.name: f"{a.provider}/{a.model}"
                for a in self.config.agents
            },
            "verifier_active": self.oven.verifier is not None,
            "steps_completed": len(self.oven.metrics_history),
            "total_steps": self.config.total_steps,
        }


# =============================================================================
# CONVENIENCE FUNCTION — the main entry point
# =============================================================================

def bake(
    model: nn.Module,
    name: str = "unnamed-model",
    modality: str = "text",
    architecture: str = "",
    domain: str = "",
    description: str = "",
    output_format: str = "text",
    scoring_guidance: str = "",
    use_verifier: bool = True,
    tokenizer=None,
    verifier=None,
    prompts: Optional[List[str]] = None,
    # Teacher
    teacher: Optional[str] = None,
    teachers: Optional[List[TeacherConfig]] = None,
    # Agents
    agents: Optional[List[AgentConfig]] = None,
    # Training
    group_size: int = 8,
    batch_size: int = 4,
    total_steps: int = 10000,
    lr: float = 1e-6,
    kl_beta: float = 0.1,
    device: str = "cuda",
    # Full config override
    config: Optional[OvenConfig] = None,
) -> OvenWrapper:
    """
    One-call setup for the Superintelligence Oven.

    Args:
        model:              Your nn.Module (any architecture)
        name:               Model name (for logging/agent context)
        modality:           "text" | "diffusion" | "motion" | "multimodal"
        architecture:       e.g. "causal LM", "UNet", "VALM"
        domain:             e.g. "general assistant", "code", "motion generation"
        description:        Free-form description — this gets fed to every agent
                            so they know what kind of GRPO they're scoring for
        output_format:      "text" | "trajectory" | "image" | "tokens"
        scoring_guidance:   Extra instructions for agents (optional)
        use_verifier:       Use QwenEmbedVerifier (text-only, skip for motion/diffusion)
        tokenizer:          HF tokenizer (auto-loaded if None)
        verifier:           Custom verifier instance (auto-loaded if None)
        prompts:            Seed training prompts
        teacher:            Initial teacher name (from teachers list)
        teachers:           Custom teacher configs (defaults used if None)
        agents:             Custom agent configs (defaults used if None)
        group_size:         GRPO completions per prompt
        batch_size:         Prompts per training step
        total_steps:        Total training steps
        lr:                 Learning rate
        kl_beta:            KL penalty weight
        device:             "cuda" or "cpu"
        config:             Full OvenConfig override (ignores other params)

    Returns:
        OvenWrapper — call .run() or .run_sync() to train.

    Examples:
        # Text model
        oven = bake(
            model=my_lm,
            name="assistant-7b",
            modality="text",
            domain="instruction following",
            description="7B causal LM for chat.",
            prompts=["Explain quantum entanglement.", ...],
        )
        oven.run_sync()

        # Motion/diffusion model
        oven = bake(
            model=my_motion_model,
            name="egirl-motion-v2",
            modality="motion",
            domain="character animation",
            description="VALM motion generator, 72-dim joints.",
            output_format="trajectory",
            use_verifier=False,
            prompts=["wave hello", "dance happily"],
        )
        oven.run_sync()
    """
    # Build model description
    model_desc = ModelDescription(
        name=name,
        modality=modality,
        architecture=architecture,
        domain=domain,
        description=description,
        output_format=output_format,
        scoring_guidance=scoring_guidance,
        use_verifier=use_verifier,
    )

    # Build config
    if config is None:
        config = OvenConfig(
            group_size=group_size,
            batch_size=batch_size,
            total_steps=total_steps,
            lr=lr,
            kl_beta=kl_beta,
            device=device,
            model_description=model_desc,
            teachers=teachers or DEFAULT_TEACHERS,
            agents=agents or DEFAULT_AGENTS,
            initial_teacher=teacher or "small_qwen3_4b",
        )
    else:
        config.model_description = model_desc

    return OvenWrapper(
        model=model,
        description=model_desc,
        config=config,
        tokenizer=tokenizer,
        verifier=verifier,
        prompts=prompts,
    )
