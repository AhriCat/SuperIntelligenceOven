"""
FrontierCalibrator — Diagnostic drift detection.

Uses top-k logprobs from DeepSeek/Grok scoring agents as a canary signal.
NOT a loss term — purely observational. Flags when policy diverges from
frontier consensus on high-probability tokens.
"""

import torch
from typing import Dict, Optional
import logging

from .config import OvenConfig

log = logging.getLogger("oven.calibrator")


class FrontierCalibrator:

    def __init__(self, config: OvenConfig):
        self.enabled = config.frontier_calibration
        self.interval = config.calibration_interval
        self.source_agent = config.calibration_agent

    def compute_drift_diagnostic(
        self,
        policy_log_probs: torch.Tensor,
        frontier_top_k: Dict[str, Dict],
        tokenizer,
    ) -> Dict:
        """
        Partial KL from top-k. Returns metrics dict, NOT a loss term.

        Args:
            policy_log_probs: (T, V) log-softmax'd policy distribution
            frontier_top_k: {"position": {token_str: logprob}} from API
            tokenizer: for mapping token strings back to IDs
        """
        if not frontier_top_k:
            return {"frontier_drift": False}

        divergences = []
        for pos_str, top_k_map in frontier_top_k.items():
            pos = int(pos_str)
            if pos >= policy_log_probs.size(0):
                continue
            for token_str, frontier_lp in top_k_map.items():
                tok_ids = tokenizer.encode(token_str, add_special_tokens=False)
                if not tok_ids:
                    continue
                tid = tok_ids[0]
                if tid >= policy_log_probs.size(-1):
                    continue
                policy_lp = policy_log_probs[pos, tid].item()
                p_frontier = torch.exp(torch.tensor(frontier_lp))
                kl_contrib = (p_frontier * (frontier_lp - policy_lp)).item()
                divergences.append(kl_contrib)

        if not divergences:
            return {"frontier_drift": False}

        mean_kl = sum(divergences) / len(divergences)
        return {
            "partial_kl_mean": mean_kl,
            "partial_kl_max": max(divergences),
            "tokens_compared": len(divergences),
            "frontier_drift": mean_kl > 0.5,
        }
