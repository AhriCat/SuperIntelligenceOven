"""
PromptSource — Prompt pool with curriculum agent injection.
"""

import random
from typing import List
import logging

log = logging.getLogger("oven.prompts")


class PromptSource:
    """Prompt pool that supports injection from the curriculum agent."""

    def __init__(self, seed_prompts: List[str]):
        self.prompts = list(seed_prompts)
        self._injected = 0

    def sample(self, n: int) -> List[str]:
        return random.sample(self.prompts, min(n, len(self.prompts)))

    def inject(self, new_prompts: List[str]):
        self.prompts.extend(new_prompts)
        self._injected += len(new_prompts)
        log.info(
            "[OVEN] Injected %d curriculum prompts (pool: %d)",
            len(new_prompts), len(self.prompts),
        )

    def __len__(self):
        return len(self.prompts)
