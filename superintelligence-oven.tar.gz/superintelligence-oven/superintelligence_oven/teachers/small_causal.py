"""
SmallCausalTeacher — Lightweight local causal LM teacher.

Default: Qwen3-4B-Thinking-2507 with shared Qwen2TokenizerFast.
Stays resident on GPU. Fast iteration, good for early training phases.
"""

import torch
import torch.nn.functional as F
from typing import Any, List, Optional, Tuple
import logging

log = logging.getLogger("oven.teachers.small")


class SmallCausalTeacher:
    """
    Tiny teacher wrapper (HF causal LM). Configurable sampling.
    If transformers is absent, teacher silently disables.
    """

    def __init__(
        self,
        model_or_name: Optional[Any] = None,
        device: str = "cuda",
        tok: Optional[Any] = None,
    ):
        self.device = torch.device(device)
        self.enabled = False
        self._tok = tok
        self._lm = None
        self._name = None

        if model_or_name is None:
            return

        try:
            from transformers import AutoModelForCausalLM

            self._name = (
                model_or_name if isinstance(model_or_name, str)
                else "Qwen/Qwen3-4B-Thinking-2507"
            )
            self._lm = AutoModelForCausalLM.from_pretrained(
                self._name, trust_remote_code=True,
            ).to(self.device).eval()
            self.enabled = True
            log.info("SmallCausalTeacher ready: %s", self._name)
        except Exception:
            log.exception("SmallCausalTeacher init failed")
            self.enabled = False

    @property
    def hf_tok(self):
        return self._tok

    @torch.inference_mode()
    def _forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Returns logits (1, T, V) on device."""
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        return self._lm(input_ids.to(self.device)).logits.float()

    @torch.inference_mode()
    def _generate_ids(
        self,
        prompt: str,
        max_new_tokens: int = 128,
        temperature: float = 0.0,
        top_p: float = 0.95,
    ) -> torch.Tensor:
        if not self.enabled:
            return torch.zeros(0, dtype=torch.long, device=self.device)
        toks = self._tok(prompt, return_tensors="pt").to(self.device)
        out = self._lm.generate(
            **toks,
            do_sample=(temperature > 0.0),
            temperature=max(1e-5, temperature),
            top_p=top_p,
            max_new_tokens=max_new_tokens,
            pad_token_id=self._tok.eos_token_id or self._tok.pad_token_id,
        )
        return out[0, toks["input_ids"].size(1):]

    @torch.inference_mode()
    def draft(
        self,
        prompts: List[str],
        max_new_tokens: int = 128,
        temperature: float = 0.0,
        top_p: float = 0.95,
    ) -> Tuple[List[str], List[torch.Tensor]]:
        """Generate completions for a list of prompts."""
        texts, ids = [], []
        for p in prompts:
            y_ids = self._generate_ids(
                p, max_new_tokens=max_new_tokens,
                temperature=temperature, top_p=top_p,
            )
            ids.append(y_ids)
            texts.append(
                self._tok.decode(y_ids, skip_special_tokens=True)
                if self.enabled else ""
            )
        return texts, ids

    @torch.inference_mode()
    def seq_logprob(
        self,
        ctx_ids: torch.Tensor,
        tgt_ids: torch.Tensor,
    ) -> torch.Tensor:
        """Log P(tgt | ctx) under the teacher. Returns scalar."""
        if not self.enabled or ctx_ids.numel() == 0 or tgt_ids.numel() == 0:
            return torch.tensor(0.0, device=self.device)
        inp = torch.cat([ctx_ids, tgt_ids], dim=0).unsqueeze(0)
        logits = self._lm(inp.to(self.device)).logits[:, :-1, :]
        tgt = inp[:, 1:].to(self.device)
        lp = F.log_softmax(logits, dim=-1)
        lp = lp.gather(-1, tgt.unsqueeze(-1)).squeeze(-1)
        Tctx = ctx_ids.numel()
        return lp[:, Tctx:].sum(dim=-1).squeeze(0)

    def evict_from_gpu(self):
        """No-op — small teacher stays resident."""
        pass
