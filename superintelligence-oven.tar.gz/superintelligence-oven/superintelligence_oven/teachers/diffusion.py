"""
SmallCausalDiffusionTeacher — Diffusion block teacher for motion/trajectory outputs.

Causal autoregressive denoising conditioned on language intent embeddings.
Designed for egirl motions (72-dim joints) but generalizable to any trajectory output.

~200M params (UNet tiny + causal proj). Distills to VALM Jacobian.
Requires: pip install diffusers

NOTE: This teacher operates on trajectories, not text tokens.
      The KL computation and generation interface differ from text teachers.
      The oven wrapper handles dispatch automatically based on teacher kind.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Any, List, Optional, Tuple
import logging

log = logging.getLogger("oven.teachers.diffusion")


class SmallCausalDiffusionTeacher(nn.Module):
    """
    Small causal teacher: Diffusion block for motion generation.
    Autoregressive: Denoises step-by-step, conditioned on lang intent.

    Args:
        joint_dim:   Dimensionality of joint space (default 72 for full-body)
        intent_dim:  Dimensionality of language intent embedding (e.g. from Qwen3-Omni)
        timesteps:   Number of diffusion timesteps
        hidden_dim:  UNet hidden dimension
    """

    def __init__(
        self,
        joint_dim: int = 72,
        intent_dim: int = 512,
        timesteps: int = 100,
        hidden_dim: int = 4096,
        device: str = "cuda",
    ):
        super().__init__()
        self.joint_dim = joint_dim
        self.intent_dim = intent_dim
        self.timesteps = timesteps
        self.hidden_dim = hidden_dim
        self.device_str = device
        self.enabled = False
        self._tok = None   # diffusion teacher doesn't use a text tokenizer

        try:
            from diffusers import UNet2DModel

            # Causal conditioner: lang intent -> embedding
            self.intent_proj = nn.Linear(intent_dim, hidden_dim)

            # Diffusion UNet (small: 2D for time-joint space)
            self.unet = UNet2DModel(
                sample_size=joint_dim,
                in_channels=1,
                out_channels=1,
                layers_per_block=1,
                block_out_channels=(hidden_dim // 2, hidden_dim),
                down_block_types=("DownBlock2D",),
                up_block_types=("UpBlock2D",),
                num_attn_heads=4,
            )

            # Causal mask for autoregressive denoising
            self.register_buffer(
                "causal_mask",
                torch.tril(torch.ones(timesteps, timesteps)),
            )

            # Beta schedule (simplified — replace with DDIM scheduler in production)
            self.register_buffer(
                "betas",
                torch.linspace(1e-4, 0.02, timesteps),
            )
            alphas = 1.0 - self.betas
            self.register_buffer("alphas_cumprod", torch.cumprod(alphas, dim=0))

            self.enabled = True
            log.info(
                "SmallCausalDiffusionTeacher ready: joints=%d, intent=%d, steps=%d",
                joint_dim, intent_dim, timesteps,
            )
        except ImportError:
            log.warning(
                "diffusers not installed — SmallCausalDiffusionTeacher disabled. "
                "pip install diffusers"
            )
            self.enabled = False
        except Exception:
            log.exception("SmallCausalDiffusionTeacher init failed")
            self.enabled = False

    @property
    def hf_tok(self):
        return self._tok

    def forward(
        self,
        noisy_joints: torch.Tensor,    # [B, T, joint_dim]
        intent_emb: torch.Tensor,       # [B, intent_dim]
        t: torch.Tensor,                # [B] timestep indices
    ) -> torch.Tensor:
        """Predict noise at timestep t, conditioned on intent."""
        B, T, _ = noisy_joints.shape

        # Condition on intent (broadcast across time)
        cond = self.intent_proj(intent_emb).unsqueeze(1).expand(-1, T, -1)

        # Flatten for UNet (time as spatial dim)
        noisy_flat = noisy_joints.view(B, 1, -1)

        # UNet forward
        pred_noise = self.unet(
            noisy_flat, timestep=t, encoder_hidden_states=cond,
        ).sample

        # Reshape and apply causal mask
        pred_noise = pred_noise.view(B, T, self.joint_dim)
        pred_noise = pred_noise * self.causal_mask[:T, :T].unsqueeze(0).to(
            pred_noise.device
        )[:, :, :1]  # broadcast mask across joint dim

        return pred_noise

    @torch.inference_mode()
    def sample(
        self,
        intent_emb: torch.Tensor,      # [B, intent_dim]
        num_steps: int = 50,
    ) -> torch.Tensor:
        """
        Causal diffusion sampling.
        Returns: [B, joint_dim] — final trajectory (mean over timesteps).
        """
        if not self.enabled:
            return torch.zeros(
                intent_emb.size(0), self.joint_dim,
                device=intent_emb.device,
            )

        B = intent_emb.size(0)
        device = intent_emb.device
        shape = (B, self.timesteps, self.joint_dim)

        # Start from noise
        x = torch.randn(shape, device=device)

        # Simple DDPM reverse process (replace with DDIM for speed)
        step_indices = torch.linspace(
            self.timesteps - 1, 0, num_steps, device=device,
        ).long()

        for t_idx in step_indices:
            t = t_idx.expand(B)
            pred_noise = self(x, intent_emb, t)

            # DDPM update
            alpha_t = self.alphas_cumprod[t_idx]
            alpha_prev = (
                self.alphas_cumprod[t_idx - 1]
                if t_idx > 0
                else torch.tensor(1.0, device=device)
            )
            beta_t = 1.0 - alpha_t / alpha_prev

            x = (1.0 / (1.0 - beta_t).sqrt()) * (
                x - beta_t / (1.0 - alpha_t).sqrt() * pred_noise
            )

            # Add noise (except last step)
            if t_idx > 0:
                noise = torch.randn_like(x)
                x = x + beta_t.sqrt() * noise

        return x.mean(dim=1)   # [B, joint_dim] — averaged trajectory

    @torch.inference_mode()
    def draft(
        self,
        prompts,                         # for diffusion: list of intent tensors or strings
        max_new_tokens: int = 128,       # ignored for diffusion
        temperature: float = 0.6,        # ignored for diffusion
        top_p: float = 0.95,             # ignored for diffusion
    ) -> Tuple[List[str], List[torch.Tensor]]:
        """
        Draft interface compatible with text teachers.
        For diffusion: prompts should be intent embeddings [B, intent_dim].
        Returns (["trajectory_str", ...], [trajectory_tensor, ...]).
        """
        if not self.enabled:
            n = len(prompts) if isinstance(prompts, list) else 1
            return [""] * n, [
                torch.zeros(self.joint_dim, device=self.device_str)
                for _ in range(n)
            ]

        # Handle both tensor and list-of-tensor inputs
        if isinstance(prompts, torch.Tensor):
            intent_emb = prompts
        elif isinstance(prompts, list) and len(prompts) > 0:
            if isinstance(prompts[0], torch.Tensor):
                intent_emb = torch.stack(prompts)
            else:
                # String prompts — can't process without an encoder
                log.warning(
                    "Diffusion teacher received string prompts — "
                    "need intent embeddings. Returning zeros."
                )
                return [""] * len(prompts), [
                    torch.zeros(self.joint_dim, device=self.device_str)
                    for _ in prompts
                ]
        else:
            return [""], [torch.zeros(self.joint_dim, device=self.device_str)]

        trajectories = self.sample(intent_emb.to(self.device_str))
        texts = [f"trajectory:{t.tolist()[:6]}..." for t in trajectories]
        ids = [t for t in trajectories]
        return texts, ids

    @torch.inference_mode()
    def trajectory_logprob(
        self,
        intent_emb: torch.Tensor,       # [B, intent_dim]
        target_trajectory: torch.Tensor, # [B, joint_dim]
        num_eval_steps: int = 10,
    ) -> torch.Tensor:
        """
        Approximate log-likelihood of a trajectory under the diffusion model.
        Uses ELBO estimation across sampled timesteps.
        Returns: [B] log-prob estimates.
        """
        if not self.enabled:
            return torch.tensor(0.0, device=intent_emb.device)

        B = intent_emb.size(0)
        device = intent_emb.device

        # Expand target to full timestep sequence
        target_full = target_trajectory.unsqueeze(1).expand(
            -1, self.timesteps, -1,
        )

        total_logprob = torch.zeros(B, device=device)

        for _ in range(num_eval_steps):
            # Random timestep
            t = torch.randint(0, self.timesteps, (B,), device=device)

            # Forward process: add noise
            alpha_t = self.alphas_cumprod[t].view(B, 1, 1)
            noise = torch.randn_like(target_full)
            noisy = alpha_t.sqrt() * target_full + (1.0 - alpha_t).sqrt() * noise

            # Predict noise
            pred_noise = self(noisy, intent_emb, t)

            # MSE as proxy for log-prob (lower noise prediction error = higher likelihood)
            mse = F.mse_loss(pred_noise, noise, reduction="none")
            mse = mse.view(B, -1).mean(dim=-1)
            total_logprob -= mse

        return total_logprob / num_eval_steps

    def seq_logprob(
        self,
        ctx_ids: torch.Tensor,
        tgt_ids: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compatibility shim with text teacher interface.
        For diffusion: ctx_ids = intent embedding, tgt_ids = target trajectory.
        """
        if not self.enabled:
            return torch.tensor(0.0, device=torch.device(self.device_str))
        return self.trajectory_logprob(
            ctx_ids.unsqueeze(0) if ctx_ids.dim() == 1 else ctx_ids,
            tgt_ids.unsqueeze(0) if tgt_ids.dim() == 1 else tgt_ids,
        ).squeeze(0)

    def _forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Compatibility shim. For diffusion, returns zeros.
        Real KL for diffusion should use trajectory_logprob instead.
        """
        log.warning(
            "_forward called on diffusion teacher — "
            "use trajectory_logprob for KL estimation"
        )
        return torch.zeros(1, 1, self.joint_dim, device=input_ids.device)

    def evict_from_gpu(self):
        """Move to CPU to free VRAM."""
        self.cpu()
        torch.cuda.empty_cache()
