"""
TeacherManager — Hot-swappable teacher pool.

Manages SmallCausalTeacher, BigCausalTeacher, and SmallCausalDiffusionTeacher
behind a unified interface. Handles:
  - Lazy loading and caching
  - VRAM-aware swapping (evict before load)
  - Auto-escalation when KL collapses
  - Agent-driven swap votes
"""

import torch
import torch.nn.functional as F
from typing import Any, Dict, Optional
import logging

from ..config import OvenConfig, TeacherConfig

log = logging.getLogger("oven.teachers.manager")


class TeacherManager:
    """
    Hot-swappable teacher pool.
    Active teacher accessible as `.current` — provides:
        - _forward(input_ids) -> logits
        - seq_logprob(ctx_ids, tgt_ids) -> scalar
        - draft(prompts, ...) -> (texts, ids)
    """

    def __init__(self, config: OvenConfig, shared_tok=None):
        self.config = config
        self.shared_tok = shared_tok
        self.device = torch.device(config.device)
        self._pool: Dict[str, Any] = {}
        self._configs: Dict[str, TeacherConfig] = {
            t.name: t for t in config.teachers
        }
        self.current: Optional[Any] = None
        self.current_name: Optional[str] = None

    # ---- lazy loading ----

    def _load(self, name: str) -> Any:
        if name in self._pool:
            return self._pool[name]

        tc = self._configs[name]
        if tc.kind == "small":
            teacher = self._make_small(tc)
        elif tc.kind == "big":
            teacher = self._make_big(tc)
        elif tc.kind == "diffusion":
            teacher = self._make_diffusion(tc)
        else:
            raise ValueError(f"Unknown teacher kind: {tc.kind!r}")

        self._pool[name] = teacher
        return teacher

    def _make_small(self, tc: TeacherConfig):
        from .small_causal import SmallCausalTeacher
        return SmallCausalTeacher(
            model_or_name=tc.model_name,
            device=str(self.device),
            tok=self.shared_tok,
        )

    def _make_big(self, tc: TeacherConfig):
        from .big_causal import BigCausalTeacher
        return BigCausalTeacher(
            model_or_name=tc.model_name,
            device=str(self.device),
            tok=self.shared_tok,
            strategy=tc.strategy,
            max_seq_len=self.config.max_seq_len,
            hf_token=tc.hf_token,
        )

    def _make_diffusion(self, tc: TeacherConfig):
        from .diffusion import SmallCausalDiffusionTeacher
        teacher = SmallCausalDiffusionTeacher(
            joint_dim=tc.joint_dim,
            intent_dim=tc.intent_dim,
            timesteps=tc.timesteps,
            hidden_dim=tc.hidden_dim,
            device=str(self.device),
        )
        if teacher.enabled:
            teacher.to(self.device)
        return teacher

    # ---- swap interface ----

    def swap_teacher(self, name: str):
        """
        Hot-swap the active teacher.
        Evicts previous teacher from GPU if applicable.
        """
        if name not in self._configs:
            raise KeyError(
                f"Unknown teacher {name!r}. "
                f"Available: {list(self._configs.keys())}"
            )

        if self.current is not None and hasattr(self.current, "evict_from_gpu"):
            self.current.evict_from_gpu()

        self.current = self._load(name)
        self.current_name = name
        log.info(
            "[OVEN] Teacher swapped -> %s (kind=%s)",
            name, self._configs[name].kind,
        )

    def register_teacher(self, tc: TeacherConfig):
        """Add a new teacher config at runtime."""
        self._configs[tc.name] = tc
        log.info("[OVEN] Registered teacher config: %s (kind=%s)", tc.name, tc.kind)

    # ---- KL computation ----

    @torch.inference_mode()
    def compute_kl(
        self,
        policy_logits: torch.Tensor,
        token_ids: torch.Tensor,
    ) -> torch.Tensor:
        """
        KL(policy || teacher) using full local distributions.

        For text teachers: standard token-level KL over vocab.
        For diffusion teachers: returns 0.0 (use trajectory_logprob separately).
        """
        if self.current is None or not self.current.enabled:
            return torch.tensor(0.0, device=self.device)

        # diffusion teachers don't have token-level KL
        kind = self._configs.get(self.current_name, TeacherConfig("", "unknown", ""))
        if kind.kind == "diffusion":
            return torch.tensor(0.0, device=self.device)

        # normalise shapes
        if policy_logits.dim() == 2:
            policy_logits = policy_logits.unsqueeze(0)
        if token_ids.dim() == 1:
            token_ids = token_ids.unsqueeze(0)

        teacher_logits = self.current._forward(token_ids)

        policy_lp = F.log_softmax(policy_logits, dim=-1)
        teacher_lp = F.log_softmax(teacher_logits, dim=-1)
        teacher_p = teacher_lp.exp()

        kl = (teacher_p * (teacher_lp - policy_lp)).sum(dim=-1).mean()
        return kl

    # ---- auto-swap heuristics ----

    def maybe_auto_swap(self, step: int, metrics: Dict) -> bool:
        if step % self.config.teacher_swap_interval != 0:
            return False

        kl_mean = metrics.get("kl_mean", 1.0)
        current_cfg = self._configs.get(self.current_name)
        if current_cfg is None:
            return False

        # small absorbed -> escalate to big
        if (
            current_cfg.kind == "small"
            and kl_mean < self.config.teacher_kl_collapse_threshold
        ):
            big_teachers = [
                n for n, c in self._configs.items() if c.kind == "big"
            ]
            if big_teachers:
                self.swap_teacher(big_teachers[0])
                return True

        # agent-driven swap
        if metrics.get("agent_swap_vote"):
            target = metrics.get("agent_swap_target")
            if target and target in self._configs:
                self.swap_teacher(target)
                return True

        return False

    # ---- info ----

    def list_teachers(self) -> Dict[str, str]:
        """Return {name: kind} for all registered teachers."""
        return {n: c.kind for n, c in self._configs.items()}

    @property
    def current_kind(self) -> Optional[str]:
        if self.current_name and self.current_name in self._configs:
            return self._configs[self.current_name].kind
        return None
