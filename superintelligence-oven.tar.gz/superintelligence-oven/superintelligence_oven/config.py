"""
Configuration dataclasses and constants for the Superintelligence Oven.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# =============================================================================
# ENDPOINT REGISTRY
# =============================================================================

PROVIDER_ENDPOINTS = {
    "claude":   "https://api.anthropic.com/v1/messages",
    "deepseek": "https://api.deepseek.com/v1/chat/completions",
    "grok":     "https://api.x.ai/v1/chat/completions",
    "openai":   "https://api.openai.com/v1/chat/completions",
}

PROVIDER_KEY_ENVS = {
    "claude":   "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "grok":     "XAI_API_KEY",
    "openai":   "OPENAI_API_KEY",
}


# =============================================================================
# AGENT CONFIG
# =============================================================================

@dataclass
class AgentConfig:
    """Per-agent configuration — each agent can hit a different frontier model."""
    name: str
    role: str
    weight: float = 0.20
    provider: str = "claude"
    model: str = "claude-sonnet-4-20250514"
    endpoint: str = ""
    api_key_env: str = ""
    temperature: float = 0.1
    logprobs: bool = False
    top_logprobs: int = 20
    is_curriculum: bool = False


DEFAULT_AGENTS = [
    AgentConfig(
        name="critic",
        role="Score correctness, coherence, and instruction-following",
        weight=0.30,
        provider="claude",
        model="claude-sonnet-4-20250514",
    ),
    AgentConfig(
        name="adversary",
        role="Probe for failure modes, hallucinations, and reward-hackable outputs",
        weight=0.20,
        provider="claude",
        model="claude-sonnet-4-20250514",
    ),
    AgentConfig(
        name="specialist",
        role="Score domain-specific accuracy and depth",
        weight=0.20,
        provider="deepseek",
        model="deepseek-chat",
        logprobs=True,
    ),
    AgentConfig(
        name="style",
        role="Score clarity, tone, and formatting quality",
        weight=0.15,
        provider="grok",
        model="grok-3-mini",
        logprobs=True,
    ),
    AgentConfig(
        name="curriculum",
        role="Analyze training dynamics and suggest next training prompts",
        weight=0.15,
        provider="claude",
        model="claude-sonnet-4-20250514",
        is_curriculum=True,
    ),
]


# =============================================================================
# TEACHER CONFIG
# =============================================================================

@dataclass
class TeacherConfig:
    """Configuration for a local teacher (KL anchor)."""
    name: str
    kind: str                   # "small" | "big" | "diffusion"
    model_name: str
    strategy: str = "quantized" # big only: "quantized" | "offload" | "hybrid"
    priority: str = "default"
    hf_token: Optional[str] = None
    # Diffusion-specific
    joint_dim: int = 72
    intent_dim: int = 512
    timesteps: int = 100
    hidden_dim: int = 4096


DEFAULT_TEACHERS = [
    TeacherConfig(
        name="small_qwen3_4b",
        kind="small",
        model_name="Qwen/Qwen3-4B-Thinking-2507",
        priority="fast_iteration",
    ),
    TeacherConfig(
        name="big_qwen3_8b_q4",
        kind="big",
        model_name="Qwen/Qwen3-8B",
        strategy="quantized",
        priority="deep_reasoning",
    ),
    TeacherConfig(
        name="big_qwen3_8b_hybrid",
        kind="big",
        model_name="Qwen/Qwen3-8B",
        strategy="hybrid",
        priority="balanced",
    ),
]


# =============================================================================
# MODEL DESCRIPTION (for wrapper)
# =============================================================================

@dataclass
class ModelDescription:
    """
    Describes the model being trained — fed to agents so they know
    what kind of GRPO they're scoring for.
    """
    name: str = "unnamed-model"
    modality: str = "text"              # "text" | "diffusion" | "multimodal" | "motion"
    architecture: str = ""              # e.g. "causal LM", "UNet diffusion", "VALM"
    domain: str = ""                    # e.g. "general assistant", "code", "motion generation"
    description: str = ""               # free-form description
    output_format: str = "text"         # "text" | "trajectory" | "image" | "tokens"
    scoring_guidance: str = ""          # extra instructions for agents
    use_verifier: bool = True           # only for text — skip for diffusion/motion

    def to_agent_prompt(self) -> str:
        """Build a context string that gets injected into every agent call."""
        parts = [
            f"MODEL BEING TRAINED: {self.name}",
            f"Modality: {self.modality}",
        ]
        if self.architecture:
            parts.append(f"Architecture: {self.architecture}")
        if self.domain:
            parts.append(f"Domain: {self.domain}")
        if self.description:
            parts.append(f"Description: {self.description}")
        parts.append(f"Output format: {self.output_format}")
        if self.scoring_guidance:
            parts.append(f"\nSCORING GUIDANCE:\n{self.scoring_guidance}")
        return "\n".join(parts)


# =============================================================================
# MAIN CONFIG
# =============================================================================

@dataclass
class OvenConfig:
    # GRPO
    group_size: int = 8
    max_seq_len: int = 2048
    grpo_clip_eps: float = 0.2
    advantage_norm: bool = True

    # KL
    kl_beta: float = 0.1
    kl_anneal: bool = False
    kl_beta_min: float = 0.01

    # Verifier
    verifier_weight: float = 0.1
    verifier_model: str = "Qwen/Qwen3-Embedding-0.6B"

    # Teachers
    teachers: List[TeacherConfig] = field(default_factory=lambda: DEFAULT_TEACHERS)
    initial_teacher: str = "small_qwen3_4b"
    teacher_swap_interval: int = 500
    teacher_kl_collapse_threshold: float = 0.01

    # Agent swarm
    agents: List[AgentConfig] = field(default_factory=lambda: DEFAULT_AGENTS)
    agent_timeout: float = 30.0
    agent_retry: int = 2

    # Frontier calibration
    frontier_calibration: bool = True
    calibration_interval: int = 50
    calibration_agent: str = "specialist"

    # Training
    lr: float = 1e-6
    batch_size: int = 4
    total_steps: int = 10000
    grad_clip: float = 1.0
    curriculum_interval: int = 100

    # Shared tokenizer
    tokenizer_name: str = "Qwen/Qwen2.5-0.5B"

    # Model description (for wrapper)
    model_description: ModelDescription = field(default_factory=ModelDescription)

    # Device
    device: str = "cuda"


# =============================================================================
# HELPERS
# =============================================================================

def resolve_endpoint(agent: AgentConfig) -> str:
    if agent.endpoint:
        return agent.endpoint
    return PROVIDER_ENDPOINTS.get(agent.provider, agent.endpoint)


def resolve_api_key(agent: AgentConfig) -> str:
    import os
    env = agent.api_key_env or PROVIDER_KEY_ENVS.get(agent.provider, "")
    return os.environ.get(env, "")
