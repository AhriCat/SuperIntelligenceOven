"""
QwenEmbedVerifier — Embedding-based semantic verifier.

Used as a lightweight local reward signal for TEXT outputs only.
Compares policy completions against teacher drafts via cosine similarity.

Skip this for diffusion/motion/image models — it only understands text.
Saves compute by catching garbage (repeated chars, noise) before
expensive API agent calls.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Tuple, Union


class QwenEmbedVerifier(nn.Module):
    """
    Qwen3 Embedding verifier.

    Two primary modes:
      1) Direct similarity: support(gold_cont, teacher_cont, ...)
         -> cosine(gold, teacher) mapped [-1,1]->[0,1]
      2) QA-style evidence: support(question=?, context=?, answer=?, evidence_spans=?)
         -> pick best evidence vs question, then cosine(answer, evidence) mapped to [0,1]

    Return:
      - by default: scalar support in [0,1]
      - if return_evidence=True and evidence path used: (support, best_evidence_str)
    """

    def __init__(
        self,
        model_name: str = "Qwen/Qwen3-Embedding-0.6B",
        device: str = "cuda",
        normalize: bool = True,
    ):
        super().__init__()
        from transformers import AutoTokenizer, AutoModel

        self.device = torch.device(device)
        self.tok = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        self.enc = AutoModel.from_pretrained(model_name, trust_remote_code=True).to(self.device)
        self.normalize = normalize
        self.eval()

    @torch.no_grad()
    def _embed(self, texts: List[str]) -> torch.Tensor:
        batch = self.tok(
            texts, padding=True, truncation=True, return_tensors="pt"
        ).to(self.device)
        out = self.enc(**batch)
        if hasattr(out, "pooler_output") and out.pooler_output is not None:
            E = out.pooler_output
        else:
            E = out.last_hidden_state[:, 0]
        if self.normalize:
            E = F.normalize(E, dim=-1)
        return E

    @torch.no_grad()
    def support(
        self,
        gold_cont: Optional[str] = None,
        teacher_cont: Optional[str] = None,
        *,
        question: Optional[str] = None,
        context: Optional[str] = None,
        answer: Optional[str] = None,
        evidence_spans: Optional[List[str]] = None,
        return_evidence: bool = False,
    ) -> Union[float, Tuple[float, str]]:
        """
        Flexible API; trainer calls with gold_cont=..., teacher_cont=....

        Case A (trainer path):
            - gold_cont and teacher_cont provided -> direct similarity.
        Case B (QA path):
            - question + context (+optional evidence_spans) (+answer) -> evidence-based score.
        """
        # ---------- Case A: direct similarity ----------
        if gold_cont is not None and teacher_cont is not None:
            E = self._embed([gold_cont, teacher_cont])
            cos = torch.dot(E[0], E[1]).clamp(-1.0, 1.0).item()
            s01 = 0.5 * (cos + 1.0)
            return float(s01)

        # ---------- Case B: QA-style evidence selection ----------
        if question is None or (context is None and not evidence_spans):
            return 0.5 if not return_evidence else (0.5, "")

        if evidence_spans and len(evidence_spans) > 0:
            candidates = [
                e.strip() for e in evidence_spans
                if isinstance(e, str) and e.strip()
            ]
        else:
            candidates = [
                x.strip()
                for x in (context or "").replace("\n", " ").split(". ")
                if x.strip()
            ]

        if len(candidates) == 0:
            candidates = [context or ""]

        qE = self._embed([question]).squeeze(0)
        cE = self._embed(candidates)
        sims = cE @ qE
        idx = int(torch.argmax(sims).item())
        best_ev = candidates[idx]

        ref_txt = answer or teacher_cont or gold_cont
        if ref_txt is None:
            return 0.5 if not return_evidence else (0.5, best_ev)

        aE = self._embed([ref_txt]).squeeze(0)
        eE = cE[idx]
        cos = torch.dot(aE, eE).clamp(-1.0, 1.0).item()
        s01 = 0.5 * (cos + 1.0)
        return (float(s01), best_ev) if return_evidence else float(s01)

    @torch.no_grad()
    def batch_support(
        self,
        gold: str,
        candidates: List[str],
    ) -> List[float]:
        """Score multiple candidates against a single gold reference."""
        if not candidates:
            return []
        all_texts = [gold] + candidates
        E = self._embed(all_texts)
        gold_e = E[0]
        cand_e = E[1:]
        sims = (cand_e @ gold_e).clamp(-1.0, 1.0)
        return [0.5 * (s.item() + 1.0) for s in sims]
