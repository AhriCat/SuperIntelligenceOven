"""
AgentSwarm — Remote reward committee.

Each agent can be a different frontier model (Claude, DeepSeek, Grok, OpenAI).
No gradients pass through here — just scalar rewards.
Handles Claude's message API vs OpenAI-compatible API shapes transparently.
"""

import asyncio
import aiohttp
import json
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple
import logging

from .config import AgentConfig, OvenConfig, resolve_endpoint, resolve_api_key

log = logging.getLogger("oven.agents")


class AgentSwarm:
    """
    Remote reward committee. Each agent independently swappable.
    """

    def __init__(self, config: OvenConfig):
        self.config = config
        self.agents: Dict[str, AgentConfig] = {a.name: a for a in config.agents}
        self.scoring_agents = [a for a in config.agents if not a.is_curriculum]
        self.curriculum_agents = [a for a in config.agents if a.is_curriculum]
        self.score_history: Dict[str, List] = defaultdict(list)
        self._model_description_prompt: str = ""

    def set_model_description(self, prompt: str):
        """Inject model description context into all agent calls."""
        self._model_description_prompt = prompt

    # ---- per-agent model swap ----

    def swap_agent_model(
        self,
        agent_name: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        endpoint: Optional[str] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
    ):
        """Hot-swap the frontier model for a specific agent."""
        if agent_name not in self.agents:
            raise KeyError(
                f"Unknown agent {agent_name!r}. "
                f"Available: {list(self.agents.keys())}"
            )
        a = self.agents[agent_name]
        if provider is not None:
            a.provider = provider
        if model is not None:
            a.model = model
        if endpoint is not None:
            a.endpoint = endpoint
        if logprobs is not None:
            a.logprobs = logprobs
        if top_logprobs is not None:
            a.top_logprobs = top_logprobs

        log.info(
            "[OVEN] Agent '%s' swapped -> %s/%s (logprobs=%s)",
            agent_name, a.provider, a.model, a.logprobs,
        )

    def swap_all_agents_model(self, provider: str, model: str, **kw):
        """Swap every scoring agent to the same frontier model."""
        for a in self.scoring_agents:
            self.swap_agent_model(a.name, provider=provider, model=model, **kw)

    # ---- scoring ----

    async def score_completions(
        self,
        prompt: str,
        completions: List[str],
        context: Optional[Dict] = None,
    ) -> Tuple[List[float], Dict]:
        """
        Fan out to all scoring agents.
        Returns (composite_scores, diagnostics).
        """
        tasks = [
            self._query_agent(agent, prompt, completions, context)
            for agent in self.scoring_agents
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        composite = [0.0] * len(completions)
        total_weight = 0.0
        diagnostics: Dict[str, Any] = {"per_agent": {}, "frontier_logprobs": {}}

        for agent, result in zip(self.scoring_agents, results):
            if isinstance(result, Exception):
                log.warning("[OVEN] Agent '%s' failed: %s", agent.name, result)
                continue

            scores, meta = result
            w = agent.weight
            total_weight += w
            for i, s in enumerate(scores):
                composite[i] += w * s

            diagnostics["per_agent"][agent.name] = scores
            self.score_history[agent.name].append(scores)

            if meta.get("logprobs"):
                diagnostics["frontier_logprobs"][agent.name] = meta["logprobs"]

        if total_weight > 0:
            composite = [s / total_weight for s in composite]

        return composite, diagnostics

    async def _query_agent(
        self,
        agent: AgentConfig,
        prompt: str,
        completions: List[str],
        context: Optional[Dict],
    ) -> Tuple[List[float], Dict]:
        """Call a single agent. Handles Claude vs OpenAI-compatible shapes."""
        system_prompt = self._build_system_prompt(agent)
        user_msg = self._build_scoring_prompt(prompt, completions, context)

        endpoint = resolve_endpoint(agent)
        api_key = resolve_api_key(agent)

        if agent.provider == "claude":
            body = {
                "model": agent.model,
                "max_tokens": 1024,
                "temperature": agent.temperature,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_msg}],
            }
            headers = {
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }
        else:
            body = {
                "model": agent.model,
                "temperature": agent.temperature,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_msg},
                ],
            }
            if agent.logprobs:
                body["logprobs"] = True
                body["top_logprobs"] = agent.top_logprobs
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

        meta: Dict[str, Any] = {}

        for attempt in range(self.config.agent_retry + 1):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        endpoint, json=body, headers=headers,
                        timeout=aiohttp.ClientTimeout(total=self.config.agent_timeout),
                    ) as resp:
                        resp.raise_for_status()
                        data = await resp.json()

                scores = self._parse_response(agent, data, len(completions))

                if agent.logprobs and agent.provider != "claude":
                    meta["logprobs"] = self._extract_logprobs(data)

                return scores, meta

            except Exception as e:
                if attempt == self.config.agent_retry:
                    raise
                log.warning(
                    "[OVEN] Agent '%s' attempt %d failed: %s",
                    agent.name, attempt + 1, e,
                )
                await asyncio.sleep(1.0 * (attempt + 1))

        return [0.5] * len(completions), meta

    def _build_system_prompt(self, agent: AgentConfig) -> str:
        parts = [
            f"You are a training reward agent.",
            f"Role: {agent.role}",
            f"Score each completion 0.0 to 1.0. Be precise — spread scores.",
            f"Return ONLY a JSON array of floats, nothing else.",
        ]
        if self._model_description_prompt:
            parts.insert(1, f"\n{self._model_description_prompt}\n")
        return "\n".join(parts)

    def _build_scoring_prompt(
        self, prompt: str, completions: List[str], context: Optional[Dict],
    ) -> str:
        parts = [f"PROMPT:\n{prompt}\n"]
        for i, c in enumerate(completions):
            parts.append(f"--- Completion {i} ---\n{c}\n")
        if context:
            parts.append(f"\nTRAINING CONTEXT:\n{json.dumps(context, default=str)}")
        return "\n".join(parts)

    def _parse_response(
        self, agent: AgentConfig, data: Dict, expected: int,
    ) -> List[float]:
        if agent.provider == "claude":
            text = data.get("content", [{}])[0].get("text", "[]")
        else:
            text = data["choices"][0]["message"]["content"]

        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1].rsplit("```", 1)[0]

        try:
            scores = json.loads(text)
        except json.JSONDecodeError:
            log.warning("[OVEN] Agent '%s' non-JSON: %s", agent.name, text[:200])
            return [0.5] * expected

        if not isinstance(scores, list) or len(scores) != expected:
            if isinstance(scores, list):
                scores = (scores + [0.5] * expected)[:expected]
            else:
                scores = [0.5] * expected

        return [max(0.0, min(1.0, float(s))) for s in scores]

    def _extract_logprobs(self, data: Dict) -> Optional[Dict]:
        try:
            lp_content = data["choices"][0].get("logprobs", {}).get("content", [])
            if not lp_content:
                return None
            return {
                str(i): {
                    entry["token"]: entry["logprob"]
                    for entry in tok_info.get("top_logprobs", [])
                }
                for i, tok_info in enumerate(lp_content)
            }
        except Exception:
            return None

    # ---- curriculum ----

    async def get_curriculum_suggestions(
        self,
        recent_prompts: List[str],
        recent_scores: List[float],
        metrics: Dict,
    ) -> List[str]:
        if not self.curriculum_agents:
            return []

        agent = self.curriculum_agents[0]
        system_prompt = (
            f"You are a curriculum designer for model training.\n"
            f"Role: {agent.role}\n"
        )
        if self._model_description_prompt:
            system_prompt += f"\n{self._model_description_prompt}\n"
        system_prompt += "Return ONLY a JSON array of 10 prompt strings."

        user_msg = (
            f"Recent prompts and mean scores:\n"
            f"{json.dumps(list(zip(recent_prompts, recent_scores)), indent=2)}\n\n"
            f"Metrics:\n{json.dumps(metrics, default=str, indent=2)}\n\n"
            f"Generate 10 new prompts targeting the model's weaknesses."
        )

        endpoint = resolve_endpoint(agent)
        api_key = resolve_api_key(agent)

        if agent.provider == "claude":
            body = {
                "model": agent.model,
                "max_tokens": 2048,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_msg}],
            }
            headers = {
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }
        else:
            body = {
                "model": agent.model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_msg},
                ],
            }
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    endpoint, json=body, headers=headers,
                    timeout=aiohttp.ClientTimeout(total=60.0),
                ) as resp:
                    data = await resp.json()

            if agent.provider == "claude":
                text = data.get("content", [{}])[0].get("text", "[]")
            else:
                text = data["choices"][0]["message"]["content"]

            text = text.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
            return json.loads(text)
        except Exception as e:
            log.warning("[OVEN] Curriculum failed: %s", e)
            return []
