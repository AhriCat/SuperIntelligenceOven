"""
SuperintelligenceOven — Main GRPO training loop.

Orchestrates:
  - Policy model generation
  - Agent swarm scoring (async)
  - Verifier blending
  - KL-anchored policy gradient
  - Frontier calibration
  - Curriculum injection
  - Teacher auto-swap
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import defaultdict
from typing import Dict, List, Optional
import asyncio
import logging

from .config import OvenConfig, ModelDescription
from .agents import AgentSwarm
from .teachers import TeacherManager
from .calibrator import FrontierCalibrator
from .prompts import PromptSource

log = logging.getLogger("oven")


class SuperintelligenceOven:
    """
    Main training loop.

    Heat sources:
      1. Policy model logits (generation + gradient)
      2. Local teacher KL anchor (full distribution, hot-swappable)
      3. Agent swarm reward (black-box, per-agent frontier model)
      4. QwenEmbedVerifier semantic reward (local, text-only)
      5. Frontier logprob calibration (diagnostic top-k)
    """

    def __init__(
        self,
        config: OvenConfig,
        policy_model: nn.Module,
        tokenizer=None,
        verifier=None,
        prompt_source: Optional[PromptSource] = None,
    ):
        self.config = config
        self.device = torch.device(config.device)

        # ---- shared tokenizer ----
        if tokenizer is not None:
            self.tokenizer = tokenizer
        else:
            from transformers import AutoTokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                config.tokenizer_name, trust_remote_code=True,
            )

        # ---- policy ----
        self.policy = policy_model.to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.policy.parameters(), lr=config.lr,
        )

        # ---- teacher manager ----
        self.teacher_mgr = TeacherManager(config, shared_tok=self.tokenizer)
        self.teacher_mgr.swap_teacher(config.initial_teacher)

        # ---- verifier ----
        self.verifier = verifier
        if verifier is None and config.model_description.use_verifier:
            try:
                from .verifier import QwenEmbedVerifier
                self.verifier = QwenEmbedVerifier(
                    model_name=config.verifier_model,
                    device=config.device,
                )
            except Exception:
                self.verifier = None
                log.warning("[OVEN] QwenEmbedVerifier not available")

        # ---- agent swarm ----
        self.swarm = AgentSwarm(config)
        # inject model description into agent prompts
        if config.model_description.description:
            self.swarm.set_model_description(
                config.model_description.to_agent_prompt()
            )

        # ---- frontier calibrator ----
        self.calibrator = FrontierCalibrator(config)

        # ---- prompt source ----
        self.prompt_source = prompt_source

        # ---- metrics ----
        self.metrics_history: List[Dict] = []

    # ================================================================
    # Wire into model.teacher / model.verifier
    # ================================================================

    def attach_to_model(self, model):
        model.teacher = self.teacher_mgr.current
        if self.verifier is not None:
            model.verifier = self.verifier

    # ================================================================
    # PUBLIC SWAP API
    # ================================================================

    def swap_teacher(self, name: str):
        self.teacher_mgr.swap_teacher(name)

    def swap_agent(self, agent_name: str, **kw):
        self.swarm.swap_agent_model(agent_name, **kw)

    def swap_all_agents(self, provider: str, model: str, **kw):
        self.swarm.swap_all_agents_model(provider, model, **kw)

    # ================================================================
    # GENERATION
    # ================================================================

    def _generate_group(self, prompt: str, n: int) -> List[Dict]:
        group = []
        input_ids = self.tokenizer(
            prompt, return_tensors="pt", truncation=True,
            max_length=self.config.max_seq_len,
        )["input_ids"].to(self.device)
        prompt_len = input_ids.size(1)

        for _ in range(n):
            with torch.no_grad():
                output = self.policy.generate(
                    input_ids,
                    do_sample=True,
                    temperature=0.8,
                    top_p=0.95,
                    max_new_tokens=self.config.max_seq_len // 2,
                    return_dict_in_generate=True,
                    output_scores=True,
                    pad_token_id=(
                        self.tokenizer.eos_token_id
                        or self.tokenizer.pad_token_id
                    ),
                )

            gen_ids = output.sequences[0, prompt_len:]
            if len(output.scores) == 0:
                continue

            scores = torch.stack(output.scores, dim=0)
            effective_len = min(gen_ids.size(0), scores.size(0))
            gen_ids_eff = gen_ids[:effective_len]

            gen_log_probs = F.log_softmax(scores[:effective_len], dim=-1)
            token_log_probs = gen_log_probs.gather(
                -1, gen_ids_eff.unsqueeze(-1)
            ).squeeze(-1)

            group.append({
                "text": self.tokenizer.decode(gen_ids_eff, skip_special_tokens=True),
                "full_ids": output.sequences[0, :prompt_len + effective_len],
                "gen_ids": gen_ids_eff,
                "gen_logits": scores[:effective_len],
                "gen_log_probs": token_log_probs,
                "prompt_len": prompt_len,
            })

        return group

    # ================================================================
    # SINGLE GRPO STEP
    # ================================================================

    async def _step(self, step_num: int, prompts: List[str]) -> Dict:
        step_metrics = defaultdict(list)
        total_loss = torch.tensor(0.0, device=self.device, requires_grad=True)
        n_items = 0
        last_diag = {}

        for prompt in prompts:
            group = self._generate_group(prompt, self.config.group_size)
            if not group:
                continue
            texts = [c["text"] for c in group]

            # ---- agent swarm scoring ----
            rewards, diag = await self.swarm.score_completions(
                prompt, texts,
                context=self._training_context(step_num),
            )
            last_diag = diag

            # ---- verifier blend (text-only) ----
            if self.verifier is not None and self.config.verifier_weight > 0:
                teacher = self.teacher_mgr.current
                gold = ""
                if teacher and teacher.enabled and hasattr(teacher, "draft"):
                    try:
                        gold_texts, _ = teacher.draft([prompt], max_new_tokens=128)
                        gold = gold_texts[0] if gold_texts else ""
                    except Exception:
                        gold = ""

                if gold:
                    vw = self.config.verifier_weight
                    for i, text in enumerate(texts):
                        v_score = self.verifier.support(
                            gold_cont=gold, teacher_cont=text,
                        )
                        rewards[i] = (1.0 - vw) * rewards[i] + vw * v_score

            rewards_t = torch.tensor(rewards, device=self.device)

            # ---- group-relative advantages ----
            if self.config.advantage_norm and rewards_t.std() > 1e-8:
                advantages = (rewards_t - rewards_t.mean()) / (rewards_t.std() + 1e-8)
            else:
                advantages = rewards_t - rewards_t.mean()

            # ---- per-completion policy gradient + KL ----
            for j, (comp, adv) in enumerate(zip(group, advantages)):
                with torch.enable_grad():
                    cur_logits = self.policy(
                        comp["full_ids"].unsqueeze(0)
                    ).logits[0, comp["prompt_len"] - 1:-1, :]

                    eff_len = min(cur_logits.size(0), comp["gen_ids"].size(0))
                    cur_logits_eff = cur_logits[:eff_len]
                    gen_ids_eff = comp["gen_ids"][:eff_len]
                    old_lp_eff = comp["gen_log_probs"][:eff_len]

                    cur_lp = F.log_softmax(cur_logits_eff, dim=-1)
                    cur_token_lp = cur_lp.gather(
                        -1, gen_ids_eff.unsqueeze(-1)
                    ).squeeze(-1)

                    seq_lp = cur_token_lp.sum()
                    old_seq_lp = old_lp_eff.sum().detach()

                    ratio = torch.exp(seq_lp - old_seq_lp)
                    clipped = torch.clamp(
                        ratio,
                        1.0 - self.config.grpo_clip_eps,
                        1.0 + self.config.grpo_clip_eps,
                    )
                    policy_loss = -torch.min(ratio * adv, clipped * adv)

                    kl_loss = self.teacher_mgr.compute_kl(
                        cur_logits_eff, gen_ids_eff,
                    )

                    if self.config.kl_anneal:
                        progress = step_num / max(self.config.total_steps, 1)
                        beta = (
                            self.config.kl_beta * (1.0 - progress)
                            + self.config.kl_beta_min * progress
                        )
                    else:
                        beta = self.config.kl_beta

                    comp_loss = policy_loss + beta * kl_loss
                    total_loss = total_loss + comp_loss
                    n_items += 1

                step_metrics["policy_loss"].append(policy_loss.item())
                step_metrics["kl_loss"].append(kl_loss.item())
                step_metrics["reward"].append(rewards[j])
                step_metrics["advantage"].append(adv.item())

        # ---- gradient update ----
        if n_items > 0:
            mean_loss = total_loss / n_items
            self.optimizer.zero_grad()
            mean_loss.backward()
            torch.nn.utils.clip_grad_norm_(
                self.policy.parameters(), self.config.grad_clip,
            )
            self.optimizer.step()

        # ---- frontier calibration ----
        if (
            self.calibrator.enabled
            and step_num % self.calibrator.interval == 0
            and step_num > 0
        ):
            frontier_lps = last_diag.get("frontier_logprobs", {}).get(
                self.config.calibration_agent
            )
            if frontier_lps and group:
                sample_lp = F.log_softmax(group[0]["gen_logits"], dim=-1)
                cal = self.calibrator.compute_drift_diagnostic(
                    sample_lp, frontier_lps, self.tokenizer,
                )
                step_metrics.update({k: [v] for k, v in cal.items()})
                if cal.get("frontier_drift"):
                    log.warning("[OVEN] Frontier drift at step %d", step_num)

        # ---- aggregate ----
        agg = {}
        for k, v in step_metrics.items():
            if isinstance(v, list) and v and isinstance(v[0], (int, float)):
                agg[k] = sum(v) / len(v)
            else:
                agg[k] = v
        agg["total_loss"] = total_loss.item() / max(n_items, 1)
        agg["n_items"] = n_items
        return agg

    # ================================================================
    # MAIN TRAINING LOOP
    # ================================================================

    async def train(self, prompt_source: Optional[PromptSource] = None):
        ps = prompt_source or self.prompt_source
        if ps is None:
            raise ValueError("No prompt source provided")

        log.info(
            "[OVEN] Firing up — %d steps, group=%d, batch=%d, teacher=%s",
            self.config.total_steps, self.config.group_size,
            self.config.batch_size, self.teacher_mgr.current_name,
        )

        for step in range(self.config.total_steps):
            prompts = ps.sample(self.config.batch_size)
            metrics = await self._step(step, prompts)
            self.metrics_history.append(metrics)

            metrics["kl_mean"] = metrics.get("kl_loss", 1.0)
            self.teacher_mgr.maybe_auto_swap(step, metrics)

            if (
                step % self.config.curriculum_interval == 0
                and step > 0
                and self.swarm.curriculum_agents
            ):
                recent_rewards = [
                    m.get("reward", 0.5)
                    for m in self.metrics_history[-self.config.curriculum_interval:]
                ]
                new_prompts = await self.swarm.get_curriculum_suggestions(
                    prompts, recent_rewards, metrics,
                )
                if new_prompts:
                    ps.inject(new_prompts)

            if step % 10 == 0:
                log.info(
                    "[OVEN] Step %5d | Loss: %.4f | Reward: %.3f | "
                    "KL: %.4f | Teacher: %s",
                    step,
                    metrics.get("total_loss", 0),
                    metrics.get("reward", 0),
                    metrics.get("kl_loss", 0),
                    self.teacher_mgr.current_name,
                )

        log.info("[OVEN] Training complete. %d steps.", self.config.total_steps)
        return self.metrics_history

    def _training_context(self, step: int) -> Dict:
        ctx = {
            "step": step,
            "total_steps": self.config.total_steps,
            "teacher": self.teacher_mgr.current_name,
            "recent_metrics": self.metrics_history[-5:] if self.metrics_history else [],
        }
        if self.config.model_description.description:
            ctx["model_description"] = self.config.model_description.to_agent_prompt()
        return ctx
