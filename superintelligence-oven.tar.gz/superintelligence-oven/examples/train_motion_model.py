"""
Example: Train a motion/diffusion model with the Superintelligence Oven.

For non-text models, the verifier is disabled (it only understands text).
The agents still score completions — they receive text descriptions of
the generated trajectories and score based on the model description context.

The diffusion teacher provides trajectory-level guidance instead of token-level KL.
"""

import asyncio

from superintelligence_oven import bake, TeacherConfig


def main():
    # ---- Your motion model (replace with actual) ----
    import torch.nn as nn

    class DummyMotionModel(nn.Module):
        """Stand-in for your VALM or motion generator."""
        def __init__(self):
            super().__init__()
            self.linear = nn.Linear(512, 72)

        def forward(self, x):
            return self.linear(x)

        def generate(self, *args, **kwargs):
            # Your actual generation logic here
            raise NotImplementedError("Replace with your motion generation")

    model = DummyMotionModel()

    # ---- Register diffusion teacher ----
    diffusion_teacher = TeacherConfig(
        name="diffusion_motion",
        kind="diffusion",
        model_name="diffusion-motion-teacher",
        joint_dim=72,
        intent_dim=512,
        timesteps=100,
        hidden_dim=4096,
    )

    # ---- Bake it ----
    oven = bake(
        model=model,

        # Model description — agents see this for every scoring call
        name="egirl-motion-v2",
        modality="motion",
        architecture="VALM with diffusion teacher distillation",
        domain="virtual character motion generation",
        description=(
            "A motion generation model that outputs 72-dimensional joint trajectories "
            "for virtual character animations. Conditioned on natural language intent "
            "embeddings from Qwen3-Omni. The model should produce smooth, natural-looking "
            "motions that match the described intent (e.g., 'wave hello', 'dance excitedly')."
        ),
        output_format="trajectory",
        scoring_guidance=(
            "Score based on: (1) Does the described motion match the intent? "
            "(2) Is the motion smooth and physically plausible? "
            "(3) Does it avoid jitter, freezing, or unnatural poses? "
            "Note: You'll receive text descriptions of trajectories, not the raw numbers."
        ),

        # Text verifier doesn't work for motion — disable it
        use_verifier=False,

        # Use the diffusion teacher for KL anchor
        teacher="diffusion_motion",
        teachers=[diffusion_teacher],

        # Training params
        group_size=4,       # fewer for expensive motion generation
        batch_size=2,
        total_steps=3000,
        device="cuda",

        # Intent prompts (for motion generation)
        prompts=[
            "wave hello enthusiastically",
            "dance excitedly to music",
            "walk forward casually",
            "sit down gracefully",
            "jump with joy",
            "bow politely",
            "stretch arms above head",
            "spin around once",
            "lean against a wall",
            "point at something in the distance",
        ],
    )

    # ---- All agents score the text descriptions of trajectories ----
    oven.swap_agent("critic",     provider="claude", model="claude-sonnet-4-20250514")
    oven.swap_agent("adversary",  provider="claude", model="claude-sonnet-4-20250514")
    oven.swap_agent("specialist", provider="claude", model="claude-sonnet-4-20250514")

    print(oven.status())
    # oven.run_sync()  # uncomment when model.generate() is implemented


if __name__ == "__main__":
    main()
