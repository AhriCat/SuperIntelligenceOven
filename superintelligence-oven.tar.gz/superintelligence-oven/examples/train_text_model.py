"""
Example: Train a text model with the Superintelligence Oven.

This shows the simplest path — use `bake()` with a model description.
The description gets injected into every agent call so they know
what kind of completions they're scoring.
"""

import asyncio
from transformers import AutoModelForCausalLM, AutoTokenizer

from superintelligence_oven import bake, TeacherConfig


def main():
    # ---- Shared tokenizer (Qwen2TokenizerFast) ----
    tok = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-0.5B", trust_remote_code=True)

    # ---- Your policy model ----
    policy = AutoModelForCausalLM.from_pretrained(
        "Qwen/Qwen2.5-0.5B",  # replace with your model
        trust_remote_code=True,
    ).to("cuda")

    # ---- Bake it ----
    oven = bake(
        model=policy,
        tokenizer=tok,

        # This description is fed to every agent so they know
        # what kind of GRPO they're doing
        name="my-assistant-0.5b",
        modality="text",
        architecture="causal LM (Qwen2.5 family)",
        domain="general instruction following",
        description=(
            "A 0.5B causal language model being fine-tuned for instruction following. "
            "The model should produce helpful, accurate, and well-structured responses. "
            "It uses a shared Qwen2 tokenizer across all teacher and student models."
        ),
        scoring_guidance=(
            "Prioritize factual accuracy and coherence. "
            "Penalize hallucinations, repetition, and off-topic responses heavily. "
            "Reward concise, direct answers over verbose padding."
        ),

        # Training params
        group_size=8,
        batch_size=2,
        total_steps=5000,
        kl_beta=0.1,

        # Seed prompts
        prompts=[
            "Explain quantum entanglement in simple terms.",
            "Write a Python function to merge two sorted lists efficiently.",
            "What are the trade-offs between GRPO and PPO for language model training?",
            "Summarize the key ideas of transformer architecture.",
            "Write a haiku about machine learning.",
            "Explain the difference between L1 and L2 regularization.",
            "How does backpropagation work in a neural network?",
            "Write a bash one-liner to find the 10 largest files in a directory.",
        ],
    )

    # ---- Customize agents ----
    oven.swap_agent("critic",     provider="claude",   model="claude-sonnet-4-20250514")
    oven.swap_agent("adversary",  provider="deepseek", model="deepseek-reasoner", logprobs=True)
    oven.swap_agent("specialist", provider="grok",     model="grok-3", logprobs=True, top_logprobs=20)
    oven.swap_agent("style",      provider="claude",   model="claude-haiku-4-5-20251001")

    # ---- Check status ----
    print(oven.status())

    # ---- Run ----
    oven.run_sync()


if __name__ == "__main__":
    main()
